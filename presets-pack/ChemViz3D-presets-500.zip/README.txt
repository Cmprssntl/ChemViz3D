ChemViz3D preset supplement — 500 molecules

Install:
  1. Close ChemViz3D.
  2. Extract this archive into the ChemViz3D data directory so that
     molecules/presets/ contains the JSON files.
     Portable: the directory containing the executable.
     Installed: ~/.config/ChemViz3D (Linux) or %APPDATA%/ChemViz3D (Windows).
  3. Start ChemViz3D again. The presets are merged with the bundled ones.

The JSON files are plain chemvz: 2 structures; you can delete individual
files to remove a preset. Inputs include the formula, Chinese name and
English IUPAC name.
